//README.txt

First look at the synchronisation process

1. First minute (Duration to be determined) : Two processes work simutaneously
	- Adam Dunkels timesynch process, which is used to get the level (# of hops) of a node
	- Sync process, actually pending

2. Timesynch process ended, sync started
	- Master initiates every minute
	- Each node is supposed to printf() after node_id*Seconds after the initiation timestamp
	- Multi hop is enabled
	- CCA is disabled 
	- The formula for the offset is still to be tinkled with (Function depending on the level, might be platform dependant)
	- A random seed is set for the rebroadcast by the slaves : to avoid as much collisions as possible (impact of the value seed to be determined)
	- 

To do :
	- Measure the impact of the values involved above, topology and size of network
	- Tests IRL

You must disable the CCA, and replace the timesynch.c and timesynch.h files in /core/net/rime/ by those provided
