
#include "contiki.h"
#include "dev/leds.h"
#include "dev/button-sensor.h"
#include "dev/light-sensor.h"
#include "dev/sht11/sht11-sensor.h"
#include "net/rime/rime.h"

#include "node-id.h"
#include "lib/random.h"
#include "sys/rtimer.h"
#include "sys/clock.h"
#include "random.h"

#include <stdio.h>

#define MAX_NODES 120

#define NUM_REPEAT 5	// how many times the start cmd is sent

#define MY_OFFSET (node_id*CLOCK_SECOND)

/*---------------------------------------------------------------------------*/
PROCESS(radiosky_process, "Broadcast example");
AUTOSTART_PROCESSES(&radiosky_process);
/*---------------------------------------------------------------------------*/

typedef struct RoundStartMsg {
  uint8_t type;			// among the above dissemination enum
  uint32_t config_id; 	// configuration id
  int run_id;		// unique (random) number to distinguish runs
  uint16_t round_seqn; 	// round sequence number
  uint16_t num_bursts;
  uint16_t burst_size;
  uint16_t timeslot;
  uint16_t env_log_interval; // seconds
  uint16_t burst_imi;		// inter-packet interval in a burst
  uint8_t channel;
  uint8_t power;
  uint8_t flags;
  clock_time_t senttime;
} RoundStartMsg;

static rtimer_clock_t recvTime;
static struct ctimer t;
static struct ctimer ot;
static struct ctimer rt;
static int sending = 0;

static struct broadcast_conn broadcast;

void notification()
{
	printf("Notification from node %d, my level is %d\n", node_id, timesynch_authority_level());
	sending = 0;
}

void
broadcast_rtimer(void * ptr)
{
	RoundStartMsg message;
	packetbuf_copyfrom(&message, sizeof(RoundStartMsg));
	broadcast_send(&broadcast);
}

void masterinit(void * ptr)
{
	timesynch_close();
	printf("Master initiated.\n");
	broadcast_rtimer(ptr);
	ctimer_set(&t, 60*CLOCK_SECOND, masterinit, &t);
}

void
broadcast_recv_char(struct broadcast_conn *c, const linkaddr_t *from)
{
	//RoundStartMsg *rx = packetbuf_dataptr();
	recvTime = packetbuf_attr(PACKETBUF_ATTR_TIMESTAMP);

	if(sending == 0)
	{
		sending = 1;
		ctimer_set(&rt, (random_rand()%5), broadcast_rtimer, NULL);
		ctimer_set(&ot, MY_OFFSET - 1*timesynch_authority_level(), notification, &t);
	}
}

static const struct broadcast_callbacks broadcast_call = {broadcast_recv_char};

/*---------------------------------------------------------------------------*/
PROCESS_THREAD(radiosky_process, ev, data)
{
  	static struct ctimer t;

  	PROCESS_EXITHANDLER(broadcast_close(&broadcast);)

 	PROCESS_BEGIN();

	broadcast_open(&broadcast, 129, &broadcast_call);

	if( node_id == 1 )
	{
		timesynch_set_authority_level(0);
		ctimer_set(&t, 60*CLOCK_SECOND, masterinit, &t);
	}

  	while(1)
	{
		PROCESS_YIELD();
  	}

  	PROCESS_END();
}
/*---------------------------------------------------------------------------*/
